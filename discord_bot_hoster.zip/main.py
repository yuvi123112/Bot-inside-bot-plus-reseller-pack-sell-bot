import os
import uuid
import subprocess
import threading
import requests
import discord
from flask import Flask, request, jsonify
from discord.ext import commands

# ========== FLASK WEB DASHBOARD ==========
app = Flask(__name__)
os.makedirs("bots", exist_ok=True)

@app.route("/upload", methods=["POST"])
def upload_bot():
    data = request.get_json()
    code = data.get("code")
    token = data.get("token")
    if not code or not token:
        return jsonify({"error": "Missing fields"}), 400

    bot_id = str(uuid.uuid4())[:8]
    bot_path = f"bots/{bot_id}.py"

    with open(bot_path, "w") as f:
        f.write(code.replace("TOKEN_PLACEHOLDER", token))

    subprocess.Popen(["python3", bot_path])
    return jsonify({"message": "Bot launched", "id": bot_id})

@app.route("/shutdown/<bot_id>", methods=["POST"])
def shutdown_bot(bot_id):
    path = f"bots/{bot_id}.py"
    if os.path.exists(path):
        os.remove(path)
        return jsonify({"message": f"Bot script deleted: {bot_id}"})
    else:
        return jsonify({"error": "Bot not found"}), 404

@app.route("/list", methods=["GET"])
def list_bots():
    return jsonify(os.listdir("bots"))

def run_dashboard():
    app.run(host="0.0.0.0", port=5000)

# ========== DISCORD HOST BOT ==========
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)
ADMIN_ID = 123456789012345678  # Replace with your Discord ID

@bot.event
async def on_ready():
    print(f"Host bot logged in as {bot.user}")

@bot.command()
async def upload(ctx, token: str):
    if ctx.author.id != ADMIN_ID:
        await ctx.send("Unauthorized")
        return

    await ctx.send("Now send your bot code (in a code block):")

    def check(msg):
        return msg.author == ctx.author and msg.channel == ctx.channel

    try:
        msg = await bot.wait_for("message", timeout=90, check=check)
        code = msg.content.strip("`")

        payload = {"code": code, "token": token}
        res = requests.post("http://127.0.0.1:5000/upload", json=payload)
        await ctx.send(res.json().get("message", "Error"))

    except Exception as e:
        await ctx.send(f"Error: {e}")

@bot.command()
async def bots(ctx):
    res = requests.get("http://127.0.0.1:5000/list")
    await ctx.send("\n".join(res.json()))

@bot.command()
async def shutdown(ctx, bot_id: str):
    res = requests.post(f"http://127.0.0.1:5000/shutdown/{bot_id}")
    await ctx.send(res.json().get("message", "Error"))

def run_discord_bot():
    bot.run(os.getenv("HOST_BOT_TOKEN"))

if __name__ == "__main__":
    threading.Thread(target=run_dashboard).start()
    run_discord_bot()
